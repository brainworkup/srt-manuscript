function appendix()
    return pandoc.RawBlock('typst', '#show: appendix')
end